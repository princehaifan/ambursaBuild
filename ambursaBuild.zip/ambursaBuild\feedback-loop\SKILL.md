---
name: feedback-loop
description: >
  Step 6 of 6 in the ambursaBuild Pipeline. Connects Claude to the sources
  where customer feedback arrives — Gmail MCP, Sentry MCP, and others — so
  it can read every new report, classify it (clear bug vs. judgment needed),
  fix clear bugs immediately, and route everything else to you. Tracks
  time-to-response and time-to-fix. Based on Vercel CEO Tip 7: "Act fast
  on what customers tell you." Saves as feedback_system.md.
---

# Feedback Loop

The speed at which you respond to customer problems
is one of the best signals of how well you are using agents.
Not the fastest company overall.
Your company specifically.
Check: does someone reply properly when a customer reports a problem?
Check: does the problem actually get fixed?
Check: how long does the whole thing take, from report to fix?
Customer feedback is not all the same.
A button that is not working: no thinking needed. Fix it fast.
A customer who says the app is confusing:
you cannot turn that into a prompt.
You have to talk to them.
This skill connects Claude to your feedback sources,
teaches it to tell the difference between the two types,
and sets up the response system that closes both.
Save as `feedback_system.md`.

---

## Prerequisites

```
READ FIRST: idea_test.md → what the app does, who the users are
READ SECOND: ux_report.md → known UX friction points, error-free sessions baseline
READ THIRD: security_spec.md → non-negotiables, what can never break
```

---

## Step 1 — Connect the Feedback Sources

```
YOUR FEEDBACK ARRIVES IN MULTIPLE PLACES.
Claude cannot act on feedback it cannot see.
Connect the sources.

THE THREE PRIMARY FEEDBACK SOURCES:

  SOURCE 1: DIRECT SUPPORT (Gmail MCP)
  Customer emails, support tickets, contact form submissions.
  How to connect:
  "Connect the Gmail MCP to Claude Code so it can read new emails
   in the support inbox. For each new email: read it, classify it,
   and respond according to the classification protocol below."

  SOURCE 2: ERROR MONITORING (Sentry MCP)
  Every error your app throws — even ones customers have not reported.
  Sentry catches problems before customers complain.
  How to connect:
  "Connect the Sentry MCP so Claude can read new error events.
   For each new error: check severity, check if it has been seen before,
   check which user flow it appears in, and respond according to
   the classification protocol below."

  SOURCE 3: IN-APP FEEDBACK (if applicable)
  Thumbs up / thumbs down, NPS surveys, in-app feedback forms.
  Connect these to a database or webhook that Claude can read.
  "Create a webhook that fires when a user submits in-app feedback.
   The webhook should write to /feedback/incoming.json.
   Claude should read this file on startup and process new entries."

ADDITIONAL SOURCES (connect as needed):
  → Slack / Discord community channels
  → App store reviews (if mobile)
  → Social media mentions (if monitored)

RULE: If you cannot connect a source today:
      create a manual triage file at /feedback/manual.md.
      Paste feedback there daily.
      Claude reads it and processes it the same way.
```

---

## Step 2 — The Classification Protocol

```
EVERY INCOMING FEEDBACK ITEM GOES THROUGH THIS PROTOCOL.

STEP 1: READ
Claude reads the full feedback item (email, error report, survey response).

STEP 2: CLASSIFY
Claude classifies it as one of FOUR types:

  TYPE 1: CLEAR BUG — FIX IMMEDIATELY
  Definition: A specific, reproducible failure.
  The fix is obvious and does not require a conversation.
  Examples:
  → "The save button throws an error after I add a photo."
  → Sentry: NullPointerException on line 42 of PaymentService.
  → "Payment failed when I tried to pay with Stripe."
  Action: Claude fixes it immediately.
  Time target: Under 2 hours from report to fix deployed.

  TYPE 2: UX CONFUSION — INVESTIGATE BEFORE FIXING
  Definition: A user is confused or frustrated, but nothing is broken.
  The app is working as designed. The design is the problem.
  Examples:
  → "I don't understand what I'm supposed to do on the second page."
  → "I keep forgetting how to get to my saved items."
  Action: Claude flags it for your review. You decide what to change.
  Do NOT let Claude guess at a UX fix without your input.
  Time target: Acknowledge within 24 hours. Decide within 72 hours.

  TYPE 3: FEATURE REQUEST — LOG AND EVALUATE
  Definition: The user wants something the app does not do.
  Examples:
  → "It would be great if I could export my data as a CSV."
  → "Can you add dark mode?"
  Action: Log to /feedback/requests.md with the user's exact words.
  Review the requests log weekly.
  Do not build a feature from a single request.
  Build it when 3+ users have asked for the same thing.

  TYPE 4: COMPLIMENT OR NOISE — ACKNOWLEDGE AND CLOSE
  Definition: Positive feedback, unactionable feedback, or spam.
  Action: Acknowledge if it came from a real user (optional reply).
  Log to /feedback/archive.md. No action required.
```

---

## Step 3 — The Response System

```
RESPONSES FOR EACH TYPE:

  TYPE 1 RESPONSE (clear bug):
  STEP A: Claude locates the bug in the code
  STEP B: Claude writes the fix
  STEP C: Claude runs the breaker agent on the affected area
  STEP D: Claude runs /sessions on the affected flow
  STEP E: If both pass: deploy the fix
  STEP F: Reply to the customer: "This has been fixed. [one sentence of what changed.]
            Please let us know if you see this again."
  LOG TO: /feedback/fixed.md with: report date, fix date, time elapsed.

  TYPE 2 RESPONSE (UX confusion):
  STEP A: Claude acknowledges to you: "User [X] reported: [summary].
           This appears to be a UX issue, not a bug. Your decision needed."
  STEP B: Claude provides context: which flow, how many users hit this path,
           what the ux_report.md said about this area.
  STEP C: You decide: fix, defer, or close.
  STEP D: Reply to the customer (Claude drafts, you send):
           "Thank you for letting us know. We're reviewing [specific thing]."
  LOG TO: /feedback/ux-queue.md

  TYPE 3 RESPONSE (feature request):
  STEP A: Claude logs the request to /feedback/requests.md with exact user words.
  STEP B: Claude checks if the same request has appeared before.
           If 3+ requests for the same feature: flag to you.
  STEP C: Optional reply to user: "Thank you — we've logged this request."
  NO BUILD ACTION without your explicit approval.

  TYPE 4 RESPONSE (compliment/noise):
  LOG AND CLOSE. No required action.
```

---

## Step 4 — The Feedback Metrics

```
TRACK THESE NUMBERS WEEKLY:

  METRIC 1: TIME TO FIRST RESPONSE
  How long from report received to first reply to the customer.
  Target: Under 24 hours for TYPE 1 and TYPE 2.
  Under 48 hours for TYPE 3.

  METRIC 2: TIME TO FIX (TYPE 1 only)
  How long from bug report to fix deployed.
  Target: Under 2 hours for CRITICAL bugs.
           Under 24 hours for HIGH bugs.
           Under one sprint for MEDIUM bugs.

  METRIC 3: RECURRING BUG RATE
  How many bugs appear more than once?
  A bug that reappears after a fix = the fix was incomplete.
  Target: 0 recurring CRITICAL bugs. Under 10% recurring overall.

  METRIC 4: FEATURE REQUEST CONVERSION
  How many logged requests become shipped features?
  This tells you if you are building what users actually want.
  Track: request date, ship date, number of users who asked.

THE WEEKLY FEEDBACK REVIEW:
  Every Monday:
  1. Read /feedback/ux-queue.md — make decisions on open UX items
  2. Read /feedback/requests.md — review for patterns (3+ same request)
  3. Check TIME TO FIX metric — was anything unresolved for too long?
  4. Check recurring bug rate — anything that keeps coming back?
  5. Close resolved items to /feedback/archive.md
```

---

## Output File: feedback_system.md

```markdown
# Feedback System
Pipeline step: 6 of 6 — ambursaBuild ✅ COMPLETE
Date: [date]

---

## Connected Feedback Sources
Gmail MCP: CONNECTED / NOT YET
Sentry MCP: CONNECTED / NOT YET
In-app feedback webhook: CONNECTED / NOT YET
Manual triage file: /feedback/manual.md — IN USE / NOT NEEDED

---

## Classification Protocol Installed
Type 1 (Clear bug → fix immediately): ACTIVE
Type 2 (UX confusion → your decision): ACTIVE
Type 3 (Feature request → log): ACTIVE
Type 4 (Compliment/noise → close): ACTIVE

---

## Feedback Metrics (weekly)
| Metric | Target | Current |
|--------|--------|---------|
| Time to first response | < 24h | [X hours] |
| Time to fix (TYPE 1) | < 2h (critical) | [X hours] |
| Recurring bug rate | < 10% | [X%] |
| Feature request conversion | track only | [N shipped / N logged] |

---

## Feedback Log Summary
TYPE 1 (bugs fixed): [N]
TYPE 2 (UX queue open): [N]
TYPE 3 (feature requests): [N]
TYPE 4 (archived): [N]

---

## Pipeline Status — COMPLETE
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ✅ direction-keeper  → direction_report.md
Step 3 ✅ security-guardian → security_spec.md
Step 4 ✅ breaker-agent     → break_report.md
Step 5 ✅ user-simulator    → ux_report.md
Step 6 ✅ feedback-loop     → feedback_system.md
```

---

## Pipeline Complete Summary (MANDATORY)

After saving `feedback_system.md`, present this EXACTLY:

```
✅ ambursaBuild Pipeline Complete.

📊 PIPELINE SUMMARY:
  Step 1 ✅ idea-tester       → idea_test.md
  Step 2 ✅ direction-keeper  → direction_report.md
  Step 3 ✅ security-guardian → security_spec.md
  Step 4 ✅ breaker-agent     → break_report.md
  Step 5 ✅ user-simulator    → ux_report.md
  Step 6 ✅ feedback-loop     → feedback_system.md

📋 DELIVERABLES READY:
  → Idea:       idea_test.md        (MVP validated, go/drop decided)
  → Direction:  direction_report.md (/direction command + drift scorecard)
  → Security:   security_spec.md    (scan setup, quality gates, non-negotiables)
  → Breaking:   break_report.md     (every breakage found and fixed)
  → UX:         ux_report.md        (first-user agent + error-free session rate)
  → Feedback:   feedback_system.md  (MCP connections + classification protocol)

🎯 APP STATUS:
  Error-free session rate:  [N]%
  Security issues resolved: [N critical/high]
  Drift score:              [0–100]
  Feedback system:          ACTIVE / PENDING CONNECTIONS
  Ready to ship:            YES / NO — [what is blocking]

✅ You are building the way the Vercel CEO builds:
   Test before you commit.
   Measure direction, not output.
   Treat security as first class.
   Lock what you will never trade.
   Break it yourself before anyone else does.
   See it as a new customer.
   Act fast on what customers tell you.
```

The pipeline is now complete.
No further steps required unless a new feature cycle begins —
in that case, return to idea-tester with the new feature as the input.
