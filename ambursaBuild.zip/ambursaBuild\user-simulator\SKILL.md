---
name: user-simulator
description: >
  Step 5 of 6 in the ambursaBuild Pipeline. Creates two agents: (1) a
  first-time user agent that uses the app without reading the code, finding
  everywhere new users get confused or drop off; (2) an error-free sessions
  agent that runs browser tests on every core customer path and reports the
  results. Based on Vercel CEO Tip 6: "See your app the way a new customer does."
  Saves as ux_report.md.
---

# User Simulator

You can never be a first-time user of your own app.
You built it.
You know where every button is.
You know what every page is for.
You know what happens when you click that thing.
Your new customers know none of this.
If the sign-up page asks for something confusing,
you will never notice, because you are never confused there.
Your customer gets confused and leaves.
You never learn why.
The Vercel CEO solves this by tracking one number: error-free sessions.
How many people get all the way through your app without anything going wrong?
He uses agents for this — sends an agent through the app,
then asks it what he could have done better.
This skill creates two agents that do exactly this.
One simulates a confused first-time user.
One tracks whether every core path completes without errors.
Save as `ux_report.md`.

---

## Prerequisites

```
READ FIRST: idea_test.md → core features, success criteria, PRD
READ SECOND: break_report.md → known friction points, broken flows
```

---

## Step 1 — The First-Time User Agent

```
THE RULE: THIS AGENT CANNOT READ THE CODE.

The moment it reads the code, it knows how the app works.
Then it is not a first-time user. It is a developer.
You need honest feedback on what the app communicates,
not on what the code does.

CREATE IT WITH THIS PROMPT:

  "Create a first-time user agent and save it to .claude/commands/newuser.md.

   This agent simulates a person who has never seen this app before.
   They do not know what it does. They only know what they can see on screen.

   CRITICAL RULE: This agent is blocked from reading any application code.
   It can ONLY run the app in a browser and interact with what is visible.
   Install a hook that blocks any bash command that is not:
   → Starting the development server
   → Opening a browser
   → Navigating to a URL
   If the agent tries to read a file, edit code, or run any other command:
   the hook blocks it and logs: 'BLOCKED: first-time user agent cannot read code.'

   The agent should:
   1. Open the app as if visiting for the first time
   2. Try to complete every core user flow listed in /specs/PRD.md
   3. For each flow, report:
      → Did they complete it? YES / NO / PARTIAL
      → Where did they get confused? (what made them pause or guess?)
      → Where did they almost give up? (what nearly lost them?)
      → What did they expect to happen that did not happen?
      → What words or labels did not make sense?
   4. Rate each flow: SMOOTH (no friction) / ROUGH (friction but completed)
                     / BROKEN (could not complete)
   5. Give an overall first-impression score (1–10) with one sentence."
```

---

## Step 2 — Reading First-Time User Feedback

```
THE THREE CATEGORIES OF FIRST-TIME USER FINDINGS:

  CATEGORY 1: CONFUSION POINTS
  Places where the agent paused, guessed, or was unsure.
  These are UX debt — they do not break the app,
  but they add friction. Friction causes drop-off.
  FIX: Clearer labels, better placeholder text, helper text,
  tooltips, or reordered steps.

  CATEGORY 2: NEAR-EXITS
  Places where the agent almost gave up.
  These are where real users leave the app.
  Your sign-up drop-off, your onboarding abandonment,
  your checkout abandonment — they live here.
  FIX: Reduce the number of steps, reduce required fields,
  add progress indicators, clarify what happens next.

  CATEGORY 3: BROKEN FLOWS
  Places where the agent could not complete the task at all.
  A new user would have left the app here and never come back.
  FIX: Treat these as CRITICAL bugs. Fix before shipping.

THE RESPONSE RULE:
  For every CATEGORY 2 and CATEGORY 3 finding:
  fix it before the app goes live.
  For CATEGORY 1 findings:
  fix the top 3 before launch, the rest in the next iteration.
```

---

## Step 3 — The Error-Free Sessions Agent

```
THE METRIC: ERROR-FREE SESSIONS
How many users complete a core path without anything going wrong?
This is the number the Vercel CEO tracks.
Not features shipped. Not tokens spent. Error-free sessions.

CREATE IT WITH THIS PROMPT:

  "Create an error-free sessions agent and save it to
   .claude/commands/sessions.md.

   This agent runs browser tests on every core user path in the app.
   The core paths are listed in /specs/PRD.md under 'Core Features.'

   For each core path, the agent should:
   1. Run the path from start to finish in a browser
   2. Record: PASS (completed without error) / FAIL (error or could not complete)
   3. For FAIL: record the exact step that failed and the error message
   4. Measure time for each step (flag any step over 3 seconds as slow)
   5. Save all results to a JSON file at /specs/sessions-[date].json

   After all paths are tested, the agent calculates:
   → Error-free session rate: [paths that passed] / [total paths] × 100
   → Slow step rate: [steps over 3s] / [total steps] × 100
   → Report: which paths failed and why

   This command should be run before every ship."
```

---

## Step 4 — The Error-Free Sessions Benchmark

```
YOUR TARGETS:

  PRE-LAUNCH MINIMUM:
  → Error-free session rate: ≥ 90%
    (at least 9 of 10 core paths complete without error)
  → No BROKEN paths (all core paths must complete)
  → No step over 5 seconds

  POST-LAUNCH TARGET:
  → Error-free session rate: ≥ 95%
  → No step over 3 seconds
  → Track week-over-week: the rate should improve, not decline

THE TRACKING RULE:
  Save every session report to /specs/sessions-[date].json.
  Compare reports week over week.
  If the rate is declining: something you shipped made the app worse.
  Run the first-time user agent again to find what changed.

WHEN TO RUN /sessions:
  MANDATORY:
  → Before every ship
  → After any change to a core user flow
  → After any change to authentication, sign-up, or onboarding
  RECOMMENDED:
  → Weekly, to track the trend
```

---

## Step 5 — Turning Findings Into Improvements

```
THE UX IMPROVEMENT LOOP:

  1. Run /newuser → get confusion points, near-exits, broken flows
  2. Fix BROKEN flows immediately
  3. Fix top 3 NEAR-EXIT points
  4. Run /sessions → confirm error-free session rate ≥ 90%
  5. Ship
  6. After 1 week: run /sessions again
  7. If rate declined: run /newuser to find what regressed
  8. Repeat

THE GUIDING RULE:
  You are not building the app you imagined.
  You are building the app your users can actually use.
  The gap between those two things is what /newuser and /sessions measure.
  Close the gap before you ship.
  Measure the gap after you ship.
  Close it again.
  That is what error-free sessions means in practice.
```

---

## Output File: ux_report.md

```markdown
# UX Report
Pipeline step: 5 of 6 — ambursaBuild
Date: [date]

---

## First-Time User Agent
Command installed: YES / NO
Location: .claude/commands/newuser.md
Code-read hook installed: YES / NO
Last run: [date]

### Flow Results
| Flow | Result | Confusion points | Near-exits | Broken |
|------|--------|-----------------|------------|--------|
| [sign-up] | SMOOTH/ROUGH/BROKEN | [list] | [list] | [yes/no] |
| [core feature 1] | SMOOTH/ROUGH/BROKEN | [list] | [list] | [yes/no] |

First-impression score: [1–10] — "[agent's one sentence]"

---

## Findings by Category
### Category 1 — Confusion Points
[List with fix for each]

### Category 2 — Near-Exits (fix before launch)
[List with fix for each]

### Category 3 — Broken Flows (fix immediately)
[List with fix for each]

---

## Error-Free Sessions Agent
Command installed: YES / NO
Location: .claude/commands/sessions.md
JSON output: /specs/sessions-[date].json

### Session Results
| Path | Result | Slow steps | Error |
|------|--------|------------|-------|
| [sign-up → core action] | PASS / FAIL | [N steps >3s] | [error msg] |

Error-free session rate: [N]%
Target: ≥ 90% (pre-launch minimum)
Status: MEETS TARGET / BELOW TARGET

---

## Pipeline Status
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ✅ direction-keeper  → direction_report.md
Step 3 ✅ security-guardian → security_spec.md
Step 4 ✅ breaker-agent     → break_report.md
Step 5 ✅ user-simulator    → ux_report.md
Step 6 ⬜ feedback-loop     → feedback_system.md
```

---

## Review Gate (MANDATORY)

After saving `ux_report.md`, present this EXACTLY:

```
✅ User simulator complete. Saved to ux_report.md.

📋 UX Summary:
- Error-free session rate: [N]% (target ≥ 90%)
- Broken flows: [N] (must be 0 before ship)
- Near-exit points: [N] (fix top 3 before ship)
- First-impression score: [1–10]

👉 You can:
  - Approve → say "approved" or "build the feedback loop"
  - Fix a broken flow → say "fix flow: [flow name]"
  - Fix a near-exit → say "fix exit: [description]"
  - Rerun user sim → say "rerun newuser"
  - Rerun sessions → say "rerun sessions"

⏸️ Waiting for approval before Feedback Loop runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the feedback loop`, `feedback loop`,
`proceed`, `next`, `go`, `ux done`, `start feedback`
