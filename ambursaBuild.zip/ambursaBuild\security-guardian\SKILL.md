---
name: security-guardian
description: >
  Step 3 of 6 in the ambursaBuild Pipeline. Covers both Vercel CEO Tips 3 and 4.
  Tip 3: Treats security debt as a first-class problem — runs security scans
  after every feature, sets up quality gates, manages slop debt deliberately.
  Tip 4: Locks your non-negotiables into CLAUDE.md so the agent can never
  accidentally trade them off. Saves as security_spec.md.
---

# Security Guardian

Agents write more code than was ever possible before.
No one can go through all of it by hand to find problems.
But the people trying to break into your app have agents too.
Models have gotten cheap enough that anyone can use them
to scan your app for security holes.
The race is not whether you will be attacked.
The race is whether you find the vulnerabilities first.
This skill has two parts.
The first part makes security a first-class problem in your build process.
The second part locks what you will never trade off
into the agent's permanent instructions
so it cannot be accidentally given away.
Save as `security_spec.md`.

---

## Prerequisites

```
READ FIRST: idea_test.md → what the app is, who uses it, how they sign in
READ SECOND: direction_report.md → current state of the build
```

---

## Part 1 — Security Debt

### Step 1.1 — The Security Scan Setup

```
RUN A SECURITY SCAN AFTER EVERY FEATURE.
Not once at the end. After every feature.

WHY:
  Security problems compound.
  A vulnerability in an authentication feature gets baked into
  every feature that uses it.
  By the end of the project, one hole is everywhere.
  After every feature: scan. Find it while it is isolated.

THE DEEPSEC APPROACH (Vercel's tool):
  Setup command creates a .deepsec folder in your project.
  Claude writes a short file about your app and how users sign in.
  Claude runs all scans.
  Deepsec gives a full report on what it found.

  If you are not using deepsec: ask your agent to build a security scan
  that checks the most recent feature for:
  → Input validation (SQL injection, XSS, command injection)
  → Authentication bypass risks
  → Exposed API keys or secrets in code
  → Insecure direct object references (IDOR)
  → Missing rate limiting on user-facing endpoints
  → Hardcoded credentials or tokens

THE SECURITY SCAN PROMPT (after each feature):
  "Run a security scan on the code changed in the last feature.
   Focus on: input validation, authentication, exposed secrets,
   IDOR, rate limiting, and injections.
   Report every issue found with:
   → Severity: CRITICAL / HIGH / MEDIUM / LOW
   → Location: file and line number
   → Description: what the vulnerability is
   → Fix: what code change resolves it
   Do not proceed with the next feature until CRITICAL and HIGH
   severity issues are resolved."
```

---

### Step 1.2 — Slop Debt Management

```
SLOP DEBT: messy code you accept in exchange for building fast.

THE SLOP DEBT RULE:
  Slop debt is acceptable in low-risk parts of the app.
  Slop debt is NOT acceptable in:
  → Authentication and authorisation
  → Payment and financial processing
  → Data storage and retrieval (especially PII)
  → Any code that touches customer data
  → Any public-facing API endpoint

BUILD A SLOP DEBT REGISTER (in /specs/decisions.md):
  For every deliberate slop debt decision, record:
  → Location (file and function)
  → What the slop is (hacky logic, unvalidated input, etc.)
  → Why it was accepted (speed, low risk, prototype stage)
  → When it will be fixed (milestone or trigger condition)
  → Risk level: LOW / MEDIUM / HIGH

THE RULE: If you cannot fill in "when it will be fixed":
          it is not slop debt. It is a vulnerability.
          Fix it now.
```

---

### Step 1.3 — Quality Gates

```
TESTS TELL YOU IF SOMETHING WORKS.
QUALITY GATES TELL YOU IF IT IS GOOD ENOUGH TO SHIP.

THE THREE QUALITY GATES:

  GATE 1: REVIEW AGENT
  Every change passes through a review agent before merging.
  The review agent checks:
  → Does this change do what the PR description says?
  → Does this change introduce any new security issues?
  → Does this change break any existing tests?
  → Does this change follow the project's conventions?
  → Is there anything obviously wrong with this code?

  INSTALL WITH THIS PROMPT:
  "Create a Claude Code hook that runs before any git commit.
   The hook should run a review agent that checks the staged changes
   against these criteria: [paste Gate 1 criteria above].
   If any check fails: block the commit and report what failed.
   If all checks pass: allow the commit."

  GATE 2: TEST COVERAGE
  Every new function or feature must have at least one test.
  The test must pass before the feature is considered done.
  "Claude, after building this feature, write tests that cover
   the main success path and the two most likely failure paths.
   Run the tests. Do not mark the feature as done until they pass."

  GATE 3: DIRECTION CHECK
  Every new feature must pass the /direction command.
  If the drift score drops below 80 after adding a feature:
  resolve the drift before adding the next one.
  (See direction-keeper skill.)
```

---

## Part 2 — Must-Not-Trade-Off Rules

### Step 2.1 — The CLAUDE.md Non-Negotiables Section

```
THE PROBLEM:
  Agents keep a lot of context in mind.
  They tend to forget rules over long sessions.
  Every trade-off decision the agent makes on its own
  is a trade-off decision you did not make.
  You need to tell the agent what it is NEVER allowed to trade.

ADD THIS SECTION TO YOUR CLAUDE.md:

  ## Must-Not-Trade-Off Rules

  These rules are non-negotiable. They apply to every change.
  Do not build any feature, fix, or refactor that violates them.
  If a task seems to require violating a rule: STOP and ask.

  ### Performance
  [Example: "No page should take more than 2 seconds to load
  on a standard connection. Do not ship a feature that makes
  any existing page slower than this threshold."]

  ### Security
  [Example: "All user input must be validated and sanitised
  before use. Never store passwords in plain text. Never
  expose API keys in client-side code."]

  ### Data Integrity
  [Example: "No operation should permanently delete user data
  without an explicit confirmation step. All deletions must
  be soft-deletable or reversible for 30 days."]

  ### Reliability
  [Example: "The core [feature] must work even if [dependency]
  is unavailable. Build graceful degradation for all external services."]

  ### [Your Custom Rule]
  [Add any rule specific to your app's most important quality]

RULE: Every non-negotiable must have a TEST.
  "No page should load in more than 2 seconds" = run a performance test.
  "All input must be sanitised" = run an injection test.
  Commit the test files to git.
  The agent cannot skip a rule it cannot skip the test for.
```

---

### Step 2.2 — The Trade-Off Decision Framework

```
WHEN YOU ARE BUILDING AND FACE A TRADE-OFF:

  STEP 1: Check the must-not-trade-off list in CLAUDE.md.
  If the trade-off involves a non-negotiable: do not make it.
  Find a different solution.

  STEP 2: If the trade-off does not involve a non-negotiable:
  Document it in /specs/decisions.md before you make it.
  Format: "We chose [X] over [Y] because [reason].
           The cost is [what you gave up].
           This decision can be revisited when [condition]."

  STEP 3: Tell the agent explicitly.
  "I am choosing [X]. This means [Y] will be slower/less polished/deferred.
   This is intentional. Do not try to restore [Y] in the background."

THE TRADE-OFF REGISTER:
  Every trade-off logged in /specs/decisions.md creates a record.
  When something breaks later and you don't know why:
  the decisions file tells you what was deliberately given up.
  It is the most underused document in most projects.
```

---

## Output File: security_spec.md

```markdown
# Security Spec
Pipeline step: 3 of 6 — ambursaBuild
Date: [date]

---

## Security Scan Setup
Scan tool: deepsec / custom agent / other
Scan frequency: after every feature
Last scan: [date]
Issues found: CRITICAL [N] / HIGH [N] / MEDIUM [N] / LOW [N]
Issues resolved: [N/N]

---

## Slop Debt Register
| Location | What | Why accepted | Fix by | Risk |
|----------|------|--------------|--------|------|
| [file:fn] | [description] | [reason] | [milestone] | LOW/MED/HIGH |

---

## Quality Gates Installed
Gate 1 (Review agent): YES / NO — [location of hook]
Gate 2 (Test coverage): YES / NO — [test runner]
Gate 3 (Direction check): YES / NO — [linked to direction command]

---

## Must-Not-Trade-Off Rules (from CLAUDE.md)
Performance rule: [text + test method]
Security rule: [text + test method]
Data integrity rule: [text + test method]
Reliability rule: [text + test method]
Custom rule: [text + test method]

---

## Trade-Off Decision Log
| Decision | Gave up | Reason | Revisit when |
|----------|---------|--------|-------------|
| [X over Y] | [Y] | [reason] | [condition] |

---

## Pipeline Status
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ✅ direction-keeper  → direction_report.md
Step 3 ✅ security-guardian → security_spec.md
Step 4 ⬜ breaker-agent     → break_report.md
Step 5 ⬜ user-simulator    → ux_report.md
Step 6 ⬜ feedback-loop     → feedback_system.md
```

---

## Review Gate (MANDATORY)

After saving `security_spec.md`, present this EXACTLY:

```
✅ Security guardian complete. Saved to security_spec.md.

📋 Security Summary:
- Critical/High issues: [N resolved / N total]
- Quality gates installed: [N/3]
- Non-negotiables locked: [N rules in CLAUDE.md]
- Trade-off decisions logged: [N]

👉 You can:
  - Approve → say "approved" or "build the breaker agent"
  - Add a non-negotiable → say "lock: [rule]"
  - Review a slop debt item → say "slop: [location]"
  - Install a missing gate → say "gate [1/2/3]: install"

⏸️ Waiting for approval before Breaker Agent runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the breaker agent`, `breaker`,
`proceed`, `next`, `go`, `security done`, `start breaking`
