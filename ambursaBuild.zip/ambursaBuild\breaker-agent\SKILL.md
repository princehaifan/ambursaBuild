---
name: breaker-agent
description: >
  Step 4 of 6 in the ambursaBuild Pipeline. Creates a breaker agent that
  attacks your own app the way an outsider would — finding every way it can
  break before anyone else does. Stress-tests concurrency, edge cases, and
  paths the building agent never thought to test. Real data is kept safe.
  Based on Vercel CEO Tip 5: "Have an agent try to break your app on purpose."
  Saves as break_report.md.
---

# Breaker Agent

Your agent built the app to be used a certain way.
When it tests the app, it uses it that exact way.
Everything passes.
But your users do not use it that way.
They skip steps.
They do two things at once.
They enter unexpected input.
They use the app on a slow connection.
They find every edge case the agent never imagined.
And they find it at scale — meaning many people hitting the same edge case
at the same time.
The Vercel CEO does not wait for this.
He gives an agent the app and tells it to break it.
On purpose.
Before anyone else does.
Your agent finds the breaks: you fix them.
Someone else finds them: it costs you a lot.
Save as `break_report.md`.

---

## Prerequisites

```
READ FIRST: idea_test.md → core features, success criteria
READ SECOND: security_spec.md → non-negotiables, known vulnerabilities
```

---

## Step 1 — Creating the Breaker Agent

```
GIVE THIS PROMPT TO CLAUDE CODE:

  "Create a breaker agent and save it to .claude/commands/break.md.

   This agent's ONLY job is to try to break the app.
   It should attack the app the way a hostile outsider would —
   not a user who wants the app to work, but someone who wants to
   find every way it can fail.

   The breaker agent must:
   1. BEFORE ANY TEST: Create copies of all app data so real data is never touched.
      All tests run against these copies. Never against production or real data.

   2. TEST CONCURRENCY:
      Simulate multiple users doing the same thing simultaneously.
      What happens when 10 users submit the same form at once?
      What happens when two users try to edit the same record simultaneously?
      What happens when a payment is submitted twice in quick succession?

   3. TEST EDGE CASES:
      What happens with empty input where text is expected?
      What happens with extremely long input?
      What happens with special characters (< > ' \" ; -- etc.)?
      What happens when a required field is missing?
      What happens when a file upload is the wrong type or oversized?

   4. TEST BROKEN FLOWS:
      What happens when a user skips step 2 of a 3-step process?
      What happens when a user navigates back during a multi-step form?
      What happens when a session expires mid-action?
      What happens when a network request fails halfway through?

   5. TEST PERFORMANCE UNDER LOAD:
      Simulate the number of users the app would have if 100 people
      used it simultaneously. Measure: response time, error rate,
      data integrity after the load test.

   6. TEST KNOWN VULNERABILITIES (from security_spec.md):
      For every MEDIUM or LOW issue not yet fixed:
      verify whether it can be exploited under normal use conditions.

   After every break attempt:
   Report: BROKEN (what broke, how to reproduce, severity) or
           HELD (what was tested, why it held, edge case covered).

   Output a full break report to break_report.md."
```

---

## Step 2 — Reading the Break Report

```
BREAK REPORT STRUCTURE:

  SECTION 1: CONCURRENCY FAILURES
  Every place the app broke when two things happened at once.
  Priority: CRITICAL if data integrity was compromised.
            HIGH if users received errors.
            MEDIUM if performance degraded but no errors.

  SECTION 2: EDGE CASE FAILURES
  Every place the app broke with unexpected input.
  Priority: CRITICAL if security was involved (e.g., injection via special chars).
            HIGH if the app crashed or showed an error page.
            MEDIUM if the app behaved unexpectedly but did not crash.

  SECTION 3: BROKEN FLOW FAILURES
  Every place the app broke when users went off the happy path.
  Priority: HIGH if users could not complete a core flow.
            MEDIUM if users encountered friction but could recover.
            LOW if the app handled it poorly but the user was not stuck.

  SECTION 4: PERFORMANCE FAILURES
  Every place the app slowed or failed under load.
  Priority: CRITICAL if the app became unusable under expected load.
            HIGH if any non-negotiable performance rule was violated.

  SECTION 5: WHAT HELD
  Every test the app passed. This is as important as the failures.
  It tells you where the app is already robust.
```

---

## Step 3 — The Fix and Retest Loop

```
THE LOOP:
  1. Run the breaker agent
  2. Read the break report
  3. Fix every CRITICAL issue immediately
  4. Fix every HIGH issue before the next feature
  5. Schedule MEDIUM issues for the next sprint
  6. Run the breaker agent again
  7. Confirm fixed issues do not reappear
  8. Repeat until no CRITICAL or HIGH issues remain

THE RETEST RULE:
  After fixing a CRITICAL or HIGH issue:
  do not mark it as resolved until the breaker agent
  has confirmed it cannot reproduce the break.

  "Claude, re-run the breaker agent focusing only on these previously
   broken areas: [list]. Confirm whether the fixes held."

THE REVIEW LOOP PROMPT (optional — have the agent run continuously):
  "Run the breaker agent, fix all CRITICAL and HIGH issues it finds,
   then run the breaker agent again. Keep looping until the break report
   has zero CRITICAL and zero HIGH issues. Report the final state."
```

---

## Step 4 — The Breaker Agent as a Pre-Ship Ritual

```
THE BREAKER AGENT IS NOT A ONE-TIME TOOL.
Run it at these moments:

  MANDATORY:
  → Before sharing the app with any external users
  → Before launching to production
  → After any major feature addition
  → After any change to authentication or payment flows

  RECOMMENDED:
  → After any change to a core user flow
  → After upgrading any dependency
  → After any change to database schema

THE PRE-SHIP BREAKER CHECKLIST:
  □ No CRITICAL issues in break report
  □ No HIGH issues in break report
  □ All concurrency tests passed
  □ All core user flows tested under broken-flow conditions
  □ Performance under expected load: within non-negotiable thresholds
  □ Real data confirmed untouched (all tests ran on copies)
```

---

## Output File: break_report.md

```markdown
# Break Report
Pipeline step: 4 of 6 — ambursaBuild
Date: [date]
Run number: [1 / ongoing]

---

## Breaker Agent Status
Command installed: YES / NO
Location: .claude/commands/break.md
Last run: [date and time]
Data copies confirmed: YES / NO

---

## Break Summary
CRITICAL issues: [N]
HIGH issues: [N]
MEDIUM issues: [N]
LOW issues: [N]
Tests that HELD: [N]

---

## Concurrency Failures
| Test | Result | Severity | Fix |
|------|--------|----------|-----|
| [concurrent form submission] | BROKEN — [description] | HIGH | [fix] |

---

## Edge Case Failures
| Input | Result | Severity | Fix |
|-------|--------|----------|-----|
| [empty input on [field]] | BROKEN — [description] | MEDIUM | [fix] |

---

## Broken Flow Failures
| Flow | Break point | Severity | Fix |
|------|-------------|----------|-----|
| [3-step form, back navigation] | BROKEN — [description] | HIGH | [fix] |

---

## Performance Failures
| Load | Response time | Error rate | Severity |
|------|---------------|------------|----------|
| [100 concurrent] | [Xs — over 2s threshold] | [X%] | HIGH |

---

## What Held
[List tests the app passed — these are confirmed robust]

---

## Fix and Retest Log
Issue [1]: [description] — Fixed [date] — Confirmed HELD [date]
Issue [2]: [description] — Fixed [date] — Confirmed HELD [date]

---

## Pipeline Status
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ✅ direction-keeper  → direction_report.md
Step 3 ✅ security-guardian → security_spec.md
Step 4 ✅ breaker-agent     → break_report.md
Step 5 ⬜ user-simulator    → ux_report.md
Step 6 ⬜ feedback-loop     → feedback_system.md
```

---

## Review Gate (MANDATORY)

After saving `break_report.md`, present this EXACTLY:

```
✅ Breaker agent complete. Saved to break_report.md.

📋 Break Summary:
- CRITICAL issues: [N] — [N resolved]
- HIGH issues: [N] — [N resolved]
- MEDIUM issues: [N]
- Tests held: [N]

👉 You can:
  - Approve → say "approved" or "build the user simulator"
  - Fix a critical issue → say "fix: [issue from report]"
  - Rerun the breaker → say "rerun breaker"
  - Focus on a specific area → say "break [area]: [focus]"

⏸️ Waiting for approval before User Simulator runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the user simulator`, `user simulator`,
`proceed`, `next`, `go`, `breaker done`, `start simulating`
