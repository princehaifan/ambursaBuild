---
name: direction-keeper
description: >
  Step 2 of 6 in the ambursaBuild Pipeline. Creates a /direction command that
  checks whether what you have built is drifting away from what you planned.
  Agents build whatever you ask — including things that move you away from your
  plan. This skill installs the direction command, runs it against all your
  requirement documents, and gives you a scorecard and drift report.
  Based on Vercel CEO Tip 2: "Measure direction, not output."
  Saves as direction_report.md.
---

# Direction Keeper

The agent will build whatever you ask.
That is the problem.
Every new idea becomes a feature.
Every feature feels like progress.
The token count goes up. The commit count goes up.
But you are not measuring what matters.
You are measuring how much you built.
Not where it is taking you.
With agents, building is the cheap part.
You can have a working feature in minutes.
So every impulse becomes code.
And code that does not serve your plan is drift.
Drift does not feel like drift while it is happening.
It feels like momentum.
This skill installs a command that finds drift before it compounds.
Save as `direction_report.md`.

---

## Prerequisites

```
READ FIRST: idea_test.md → PRD, core features, success criteria
```

---

## Step 1 — The Direction Command Setup

```
INSTALL THE DIRECTION COMMAND INTO YOUR PROJECT.

GIVE THIS PROMPT TO CLAUDE CODE:

  "Create a slash command called 'direction' and save it to
   .claude/commands/direction.md.

   When I run /direction, this command should:
   1. Read every requirement document in the /specs folder
   2. Spin up a separate subagent for each document
   3. Each subagent compares what is currently built against
      that document's requirements
   4. The main agent collects all subagent reports and checks
      for any changes that are NOT covered by any specs document
   5. Output a direction report with:
      → A drift scorecard (0–100, where 100 = perfectly on plan)
      → A list of features built that are NOT in any specs doc
      → A list of requirements NOT yet built
      → A recommended action (keep drift / revert drift / update specs)

   The specs folder is at: /specs
   The command should be reloadable with /reload-mcp."

AFTER CLAUDE CREATES THE COMMAND:
  Run: /reload-mcp  (or the reload command for your agent)
  Then run: /direction
  The first run establishes your baseline.
```

---

## Step 2 — Reading the Direction Report

```
THE DIRECTION SCORECARD:

  SCORE 90–100: ON PLAN
  What you built matches what you planned.
  Proceed with confidence.

  SCORE 70–89: MINOR DRIFT
  A few features or changes have moved outside the plan.
  Review the drift list.
  Decide: update the specs to reflect these changes, or revert them.

  SCORE 50–69: SIGNIFICANT DRIFT
  The app is materially different from the plan.
  Some of the drift may be improvements. Some may be waste.
  Stop building new features.
  Run the direction command. Work through the drift list before continuing.

  SCORE BELOW 50: MAJOR DRIFT
  The app has moved substantially away from the original plan.
  This is a planning failure, not a building failure.
  Options:
  → Option A: Accept the new direction. Rewrite the specs to match what you built.
              Treat the current state as the new plan. Continue from here.
  → Option B: Revert the drift. Use git to roll back to the last on-plan state.
              Rebuild with the specs enforced more strictly.
  → Option C: Acknowledge the plan was wrong. Rewrite the specs from scratch.
              The MVP showed you something the plan did not account for.
              Update the plan. Then re-run /direction to confirm the new baseline.
```

---

## Step 3 — Drift Management Protocol

```
FOR EVERY ITEM IN THE DRIFT LIST:

  ITEM TYPE A: FEATURE BUILT THAT IS NOT IN SPECS
  Decision options:
  → KEEP AND DOCUMENT: Add this feature to specs/features.md.
    Write why it was added and what it replaces or adds to.
  → REVERT: Use git to remove this change.
    "git revert [commit]" if the drift is recent.
    If deeply embedded: document as technical debt in specs/decisions.md.

  ITEM TYPE B: REQUIREMENT NOT YET BUILT
  Decision options:
  → SCHEDULE: Add to the build queue. Assign a priority.
  → DEPRIORITISE: Move to a future milestone in the PRD.
    Update the PRD to reflect this.
  → REMOVE: If the requirement no longer makes sense, remove it from the PRD.
    Document why in specs/decisions.md.

THE SPECS UPDATE RULE:
  Specs that do not match the current state of the app are useless.
  After every drift review: update the specs to reflect reality OR
  update the app to reflect the specs.
  Never leave them out of sync for more than one week.
```

---

## Step 4 — The Direction Command as a Habit

```
WHEN TO RUN /direction:

  MANDATORY:
  → Before starting any new feature
  → Before merging any branch
  → Before sharing the app with users or stakeholders
  → Any time you feel uncertain about where the project is going

  RECOMMENDED:
  → At the end of every working session
  → Any time you've had an idea and immediately asked Claude to build it
    (impulse features are the most common source of drift)

THE WEEKLY DIRECTION CHECK:
  Every Monday (or start of your working week):
  1. Run /direction
  2. Review the scorecard
  3. For any drift below 80: resolve before building new features
  4. Update specs if the drift was intentional

THE DIRECTION RULE:
  You should never be surprised by what /direction finds.
  If you are surprised: you have been building without checking.
  Run /direction more often.
```

---

## Step 5 — Tracking Intentional Direction Changes

```
NOT ALL DRIFT IS BAD.
Sometimes you build something the plan did not anticipate
and it turns out to be better than what the plan said.

THE INTENTIONAL PIVOT LOG (add to specs/decisions.md):

  For every intentional direction change, record:
  → What changed
  → Why (what did you learn that changed the plan?)
  → What was replaced or removed
  → Date

THIS LOG SERVES THREE PURPOSES:
  1. It tells you why the app is the way it is (future reference)
  2. It tells the agent what has been decided (context for future sessions)
  3. It tells stakeholders that you are building intentionally, not randomly

THE RULE: If you cannot explain why a direction change happened,
          it was drift, not a pivot.
          Drift should be reverted. Pivots should be documented.
```

---

## Output File: direction_report.md

```markdown
# Direction Report
Pipeline step: 2 of 6 — ambursaBuild
Date: [date]
Run number: [1 / ongoing]

---

## Direction Command Status
Command installed: YES / NO
Location: .claude/commands/direction.md
Last run: [date and time]

---

## Drift Scorecard
Score: [0–100]
Status: ON PLAN / MINOR DRIFT / SIGNIFICANT DRIFT / MAJOR DRIFT

---

## Drift List
Features built NOT in specs:
  1. [feature] — Decision: KEEP (added to specs) / REVERT
  2. [feature] — Decision: KEEP / REVERT

Requirements NOT yet built:
  1. [requirement] — Decision: SCHEDULE / DEPRIORITISE / REMOVE
  2. [requirement] — Decision: SCHEDULE / DEPRIORITISE / REMOVE

---

## Action Taken
[What was done to resolve drift or update specs]

---

## Intentional Pivot Log
[Any deliberate direction changes recorded here]

---

## Pipeline Status
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ✅ direction-keeper  → direction_report.md
Step 3 ⬜ security-guardian → security_spec.md
Step 4 ⬜ breaker-agent     → break_report.md
Step 5 ⬜ user-simulator    → ux_report.md
Step 6 ⬜ feedback-loop     → feedback_system.md
```

---

## Review Gate (MANDATORY)

After saving `direction_report.md`, present this EXACTLY:

```
✅ Direction check complete. Saved to direction_report.md.

📋 Direction Summary:
- Drift score: [0–100]
- Status: ON PLAN / MINOR DRIFT / SIGNIFICANT DRIFT / MAJOR DRIFT
- Features outside specs: [N]
- Requirements not yet built: [N]
- Action taken: [one sentence]

👉 You can:
  - Approve → say "approved" or "move to security"
  - Resolve drift → say "revert: [feature name]"
  - Accept drift → say "document: [feature name]"
  - Rewrite specs → say "pivot: [new direction]"

⏸️ Waiting for approval before Security Guardian runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `move to security`, `security guardian`,
`proceed`, `next`, `go`, `direction clean`, `start security`
