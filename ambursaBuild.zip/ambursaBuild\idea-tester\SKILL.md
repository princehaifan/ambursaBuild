---
name: idea-tester
description: >
  Step 1 of 6 in the ambursaBuild Pipeline. Tests your app idea before you
  commit to building it. Creates a specs folder with a PRD, builds an MVP to
  validate the idea quickly, and decides whether the idea is worth pursuing
  before anything else is built on top of it. Based on Vercel CEO Tip 1:
  "Test ideas before you commit to them." Saves as idea_test.md.
---

# Idea Tester

Most people start building the full app.
They sketch a feature list, open Claude Code, and start prompting.
Weeks later they discover the core idea had a problem.
Everything they built sits on top of a decision that was wrong.
Fixing it means going back through the whole app.
The Vercel CEO does not do this.
He makes a new project for every idea.
He builds an MVP.
He has an agent check from scratch if it really works.
Not because someone said it would.
Because he tested it himself.
You will do the same.
Save as `idea_test.md`.

---

## The Rule: Vibes Are Not Tests

```
THE VIBE PROBLEM:

  Most developers go off vibes with new ideas.
  "I heard this approach works better."
  "Everyone says this is the right way."
  "This model is supposed to handle this well."

  But they never check if that's actually true.

  THE FIX:
  Test everything yourself.
  Every new idea gets its own project.
  Every claim gets verified.
  You trust what you can see, not what you heard.
```

---

## Step 1 — The Specs Folder

```
BEFORE WRITING A SINGLE LINE OF CODE:
Create the specs folder.

STRUCTURE:
  /specs
    PRD.md          ← the product requirements document (you create this first)
    features.md     ← feature list extracted from the PRD
    decisions.md    ← key decisions and why you made them

THE PRD (Product Requirements Document):
  Write it before the agent touches anything.
  It is the plan the agent builds against.
  Without it: the agent builds whatever it wants.

PRD STRUCTURE:
  ## What This App Does
  One paragraph. What problem does it solve? Who is it for?

  ## Core Features (MVP)
  List only the features that make the app worth using.
  Not nice-to-haves. Not future ideas. Must-haves only.
  Max 5–7 features for an MVP.

  ## What This App Is NOT
  Explicitly list what you are NOT building.
  This prevents scope creep before it starts.

  ## Success Criteria
  How will you know the MVP worked?
  3–5 measurable outcomes.

  ## Open Questions
  What do you not know yet that could change the plan?

RULE: If you cannot fill out this PRD: the idea is not ready to build.
      Clarify the idea before creating a project for it.
```

---

## Step 2 — The MVP Build

```
THE MVP RULE:
  Build only the features that let you answer this question:
  "Is this idea actually worth building?"

  An MVP is NOT:
  × A polished product
  × A product with all features
  × Something you'd ship to paying customers

  An MVP IS:
  ✓ The first working version of the core idea
  ✓ Built as fast as possible
  ✓ Just detailed enough to show if the idea works

THE MVP PROMPT (give this to Claude Code):
  "Build an MVP of this app based on the PRD in /specs/PRD.md.
   Include only the Core Features listed there.
   Do not add any features not in that list.
   The goal is to test if the idea works, not to build a production app.
   When done, tell me what works, what does not, and what surprised you."

AFTER THE MVP IS BUILT:
  Answer these questions before proceeding:
  1. Does the app do what I thought it would?
  2. Did any part of the idea not work as expected?
  3. Is the core feature actually useful once it's real?
  4. Would I keep building this? Why?

  IF YES TO ALL FOUR: proceed to direction-keeper.
  IF NO TO ANY: document why, then decide: pivot or drop.
```

---

## Step 3 — The Agent Verification Test

```
DO NOT TRUST YOUR OWN TESTING.
You built it. You know where everything is.
You will not find the problems a stranger finds.

GIVE THE MVP TO AN AGENT WITH THESE INSTRUCTIONS:
  "You are testing this app as if you have never seen it before.
   You do not know how it works.
   Try to use every core feature listed in /specs/PRD.md.
   For each feature, tell me:
   → Did it work? (yes / partial / no)
   → What was confusing?
   → What did you expect to happen that did not happen?
   → What broke?
   Do not read the code. Only use the running app."

THE FOUR OUTCOMES:
  OUTCOME A — All features work, nothing confusing:
  Idea is validated. Document it and proceed.

  OUTCOME B — Features work but UX is confusing:
  The idea works. The execution needs iteration.
  Fix UX issues before proceeding.

  OUTCOME C — Core feature doesn't work as expected:
  The idea has a fundamental problem.
  Decide: pivot the core feature, or drop the idea.

  OUTCOME D — The agent cannot figure out how to use the app:
  The idea is too complex to explain without a manual.
  Simplify before proceeding.
```

---

## Step 4 — The Go / Drop Decision

```
ONE QUESTION DETERMINES EVERYTHING:
"Is this idea worth the investment of building the full app?"

THE GO CRITERIA (need all three to proceed):
  □ The core feature works as the PRD described
  □ An agent can use it without reading the code
  □ You would use this app yourself

THE DROP CRITERIA (even one means stop):
  × The core idea does not work in practice
  × The app solves a problem you thought existed but doesn't
  × Building the full version would require solving a problem
    you have no path to solving

THE PIVOT CRITERIA (don't drop, but don't build as-is):
  → The core insight is right but the execution is wrong
  → Rewrite the PRD with the new direction
  → Build a second MVP
  → Re-run this skill

RULE: Dropping an MVP takes one day. Dropping a full app takes three weeks.
      The decision you make here saves everything that comes after it.
```

---

## Output File: idea_test.md

```markdown
# Idea Test
Pipeline step: 1 of 6 — ambursaBuild
Date: [date]
App name: [name]

---

## PRD Summary
What it does: [one paragraph]
Core features (MVP): [list — max 7]
What it is NOT: [list]
Success criteria: [3–5 measurables]
Open questions: [list]

---

## MVP Build
Build completed: YES / NO
Time to build: [X hours]
Unexpected problems during build: [list or none]

---

## Agent Verification Test
Feature 1: WORKS / PARTIAL / BROKEN — [notes]
Feature 2: WORKS / PARTIAL / BROKEN — [notes]
Feature 3: WORKS / PARTIAL / BROKEN — [notes]
Agent confusion points: [list]
Agent breakage points: [list]

---

## Go / Drop / Pivot Decision
Decision: GO / DROP / PIVOT
Reason: [one sentence]
If pivot: new direction: [describe]

---

## Pipeline Status
Step 1 ✅ idea-tester       → idea_test.md
Step 2 ⬜ direction-keeper  → direction_report.md
Step 3 ⬜ security-guardian → security_spec.md
Step 4 ⬜ breaker-agent     → break_report.md
Step 5 ⬜ user-simulator    → ux_report.md
Step 6 ⬜ feedback-loop     → feedback_system.md
```

---

## Review Gate (MANDATORY)

After saving `idea_test.md`, present this EXACTLY:

```
✅ Idea test complete. Saved to idea_test.md.

📋 Idea Summary:
- Decision: GO / DROP / PIVOT
- Core features tested: [N/N work]
- Agent confusion points: [N]
- Agent breakage points: [N]

👉 You can:
  - Approve → say "approved" or "build the direction keeper"
  - Pivot → say "pivot: [new direction]"
  - Retest a feature → say "retest: [feature name]"
  - Drop the idea → say "drop: [reason]"

⏸️ Waiting for approval before Direction Keeper runs.
```

**NEVER** proceed automatically.

Approval keywords: `approved`, `build the direction keeper`, `direction`,
`proceed`, `next`, `go`, `idea confirmed`, `start tracking`
